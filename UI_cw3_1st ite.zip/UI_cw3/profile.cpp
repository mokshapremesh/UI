#include "profile.h"
#include "ui_profile.h"
#include "home.h"

Home* h2;
Profile::Profile(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Profile)
{
    ui->setupUi(this);

    resize(320, 650);
}

Profile::~Profile()
{
    delete ui;
}

void Profile::on_goBackButton_clicked()
{
    hide();
    h2 = new Home(this);
    h2->show();
}
