#include "home.h"
#include "ui_home.h"
#include "profile.h"
#include <QTextEdit>
#include <QTimer>
#include <QMessageBox>
#include <QDesktopWidget>
#include <QFileDialog>
#include <QMediaPlayer>
#include <QVideoWidget>

Home::Home(QWidget *parent) :
    QDialog(parent)
{
    // Button on the left side of the search line
    QPushButton *addButton = new QPushButton("+", this);

    // Search line edit
    QLineEdit *searchEdit = new QLineEdit(this);
    searchEdit->setPlaceholderText("Logo or Search here");

    // Profile button
    QPushButton *profileButton = new QPushButton("My Profile", this);
    connect(profileButton, &QPushButton::clicked, this, &Home::on_profileButton_clicked);

    // Top layout with new button, search, and profile button
    QHBoxLayout *topLayout = new QHBoxLayout;
    topLayout->addWidget(addButton);
    topLayout->addWidget(searchEdit);
    topLayout->addWidget(profileButton);

    // Middle section for video player controls
    playButton = new QPushButton("play / stop", this);
    timeSlider = new QSlider(Qt::Horizontal, this);

    timeSlider->setRange(0, 0); // Initial range
    connect(timeSlider, &QSlider::sliderMoved, this, &Home::sliderMoved);

    timeSlider->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    QLabel *timeLabel = new QLabel("00:00:00", this);
    QComboBox *speedBox = new QComboBox(this);
    speedBox->addItem("1x");

    QHBoxLayout *middleLayout = new QHBoxLayout;
    middleLayout->addWidget(playButton);
    middleLayout->addWidget(timeSlider);
    middleLayout->addWidget(timeLabel);
    middleLayout->addWidget(speedBox);

    // Thumbnails section
    QPushButton *thumb1Button = new QPushButton("Video thumbnail1", this);
    QPushButton *thumb2Button = new QPushButton("Video thumbnail2", this);
    QPushButton *thumb3Button = new QPushButton("Video thumbnail3", this);

    // Set minimum size for thumbnail buttons
    thumb1Button->setMinimumSize(200, 150);
    thumb2Button->setMinimumSize(200, 150);
    thumb3Button->setMinimumSize(200, 150);

    QHBoxLayout *thumbnailLayout = new QHBoxLayout;
    thumbnailLayout->addWidget(thumb1Button);
    thumbnailLayout->addWidget(thumb2Button);
    thumbnailLayout->addWidget(thumb3Button);

    // Create a scroll area and set its widget to hold the thumbnail layout
    QScrollArea *thumbnailScrollArea = new QScrollArea(this);
    thumbnailScrollArea->setWidgetResizable(true);

    QWidget *thumbnailWidget = new QWidget;
    thumbnailWidget->setLayout(thumbnailLayout);

    thumbnailScrollArea->setWidget(thumbnailWidget);

    // Bottom section for comments
    QLabel *usernameLabel = new QLabel("Username", this);
    QPushButton *viewComments = new QPushButton("View Comments", this);
    connect(viewComments, &QPushButton::clicked, this, &Home::on_viewComments_clicked);
    QVBoxLayout *commentsLayout = new QVBoxLayout;
    commentsLayout->addWidget(usernameLabel);
    commentsLayout->addWidget(viewComments);

    // Main layout
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(topLayout);

    // Video player setup
    player = new QMediaPlayer(this);
    videoWidget = new QVideoWidget(this);
    player->setVideoOutput(videoWidget);
    videoWidget->setMinimumHeight(200);

    mainLayout->addWidget(videoWidget);
    mainLayout->addLayout(middleLayout);
    mainLayout->addWidget(thumbnailScrollArea);
    mainLayout->addLayout(commentsLayout);

    // Connect the add button to a new slot
    connect(addButton, &QPushButton::clicked, this, &Home::on_addButton_clicked);

    connect(playButton, &QPushButton::clicked, this, &Home::togglePlayStop);

    // Connect media player signals
    connect(player, &QMediaPlayer::durationChanged, this, &Home::durationChanged);
    connect(player, &QMediaPlayer::positionChanged, this, &Home::positionChanged);


    // Set the layout for the QDialog
    setLayout(mainLayout);

    // Initialize the timer
    notificationTimer = new QTimer(this);
    connect(notificationTimer, &QTimer::timeout, this, &Home::showNotification);
    // Set the timeout duration to 5000 milliseconds (5 seconds)
    notificationTimer->setInterval(5000);
    // Start the timer
    notificationTimer->start();


    // Set a minimum size for the dialog
    // (Use iPhone SE as a reference)
    setMinimumSize(320, 650);
    resize(320, 650);
}

void Home::on_viewComments_clicked()
{
    if (commentsTextEdit == nullptr)
    {
        // Create the QTextEdit if it doesn't exist
        commentsTextEdit = new QTextEdit(this);
        commentsTextEdit->setPlaceholderText("Type your comments here");
        QVBoxLayout *layout = qobject_cast<QVBoxLayout *>(this->layout());
        layout->addWidget(commentsTextEdit);
    }

    // Toggle visibility of the QTextEdit
    commentsTextEdit->setVisible(!commentsTextEdit->isVisible());
}

void Home::showNotification()
{
    // Create the notification dialog
    QMessageBox notificationDialog(this);
    notificationDialog.setWindowTitle("Notification");
    notificationDialog.setText("Time to upload videos!");

    // Set the size of the dialog
    notificationDialog.setFixedSize(200, 30);

    // Get the geometry of the main window
    QRect mainWindowGeometry = this->geometry();

    // Calculate the position to place the notification above the main window
    int x = mainWindowGeometry.x() + (mainWindowGeometry.width() - notificationDialog.width()) / 2.5;
    int y = mainWindowGeometry.y() - notificationDialog.height() + 35;

    // Move the dialog to the calculated position
    notificationDialog.move(x, y);

    // Show the notification dialog
    notificationDialog.exec();

    // Stop the timer when the user opens another dialog
    notificationTimer->stop();
}

void Home::on_addButton_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Select Video"), "", tr("Video Files (*.mp4 *.avi *.mkv)"));
    if (!fileName.isEmpty())
    {
        player->setMedia(QUrl::fromLocalFile(fileName));

        if(player->error() != QMediaPlayer::NoError) {
            // Handle error (e.g., show an error message)
        }

        player->play();
    }
}

void Home::togglePlayStop()
{
    if (player->state() == QMediaPlayer::PlayingState) {
        player->pause();
        playButton->setText("play");
    } else {
        player->play();
        playButton->setText("stop");
    }
}

void Home::durationChanged(qint64 duration)
{
    timeSlider->setMaximum(duration);
}

void Home::positionChanged(qint64 position)
{
    if (!timeSlider->isSliderDown()) {
        timeSlider->setValue(position);
    }
}

void Home::sliderMoved(int position)
{
    player->setPosition(position);
}

Home::~Home(){}

void Home::on_profileButton_clicked()
{
    // Stop the timer when the user opens another dialog
    notificationTimer->stop();
    hide();
    p = new Profile(this);
    p->show();
}
