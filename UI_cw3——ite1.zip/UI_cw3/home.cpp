#include "home.h"
#include "ui_home.h"
#include "profile.h"

Home::Home(QWidget *parent) :
    QDialog(parent)
{
    // Top row with search and profile button
    QLineEdit *searchEdit = new QLineEdit(this);
    searchEdit->setPlaceholderText("Logo or Search here");
    QPushButton *profileButton = new QPushButton("My Profile", this);
    connect(profileButton, &QPushButton::clicked, this, &Home::on_profileButton_clicked);

    QHBoxLayout *topLayout = new QHBoxLayout;
    topLayout->addWidget(searchEdit);
    topLayout->addWidget(profileButton);

    // Player frame placeholder
    QFrame *playerFrame = new QFrame(this);
    playerFrame->setFrameShape(QFrame::StyledPanel);
    playerFrame->setMinimumHeight(200); // Adjust height as needed

    // Middle section for video player controls
    QPushButton *playButton = new QPushButton("play / stop", this);
    QSlider *timeSlider = new QSlider(Qt::Horizontal, this);
    timeSlider->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred); // Make slider expandable
    QLabel *timeLabel = new QLabel("00:00:00", this);
    QComboBox *speedBox = new QComboBox(this);
    speedBox->addItem("1x");

    QHBoxLayout *middleLayout = new QHBoxLayout;
    middleLayout->addWidget(playButton);
    middleLayout->addWidget(timeSlider);
    middleLayout->addWidget(timeLabel);
    middleLayout->addWidget(speedBox);

    // Thumbnails section
    QPushButton *thumb1Button = new QPushButton("Video thumbnail1", this);
    QPushButton *thumb2Button = new QPushButton("Video thumbnail2", this);
    QPushButton *thumb3Button = new QPushButton("Video thumbnail3", this);

    QHBoxLayout *thumbnailLayout = new QHBoxLayout;
    thumbnailLayout->addWidget(thumb1Button);
    thumbnailLayout->addWidget(thumb2Button);
    thumbnailLayout->addWidget(thumb3Button);

    // Bottom section for comments
    QLabel *usernameLabel = new QLabel("Username", this);
    QTextEdit *commentsEdit = new QTextEdit(this);
    commentsEdit->setPlaceholderText("Comments");

    QVBoxLayout *commentsLayout = new QVBoxLayout;
    commentsLayout->addWidget(usernameLabel);
    commentsLayout->addWidget(commentsEdit);

    // Main layout
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(topLayout);
    mainLayout->addWidget(playerFrame);
    mainLayout->addLayout(middleLayout);
    mainLayout->addLayout(thumbnailLayout);
    mainLayout->addLayout(commentsLayout);

    // Set the layout for the QDialog
    setLayout(mainLayout);
}

Home::~Home()
{
    delete ui;
}

void Home::on_profileButton_clicked()
{
    hide();
    p = new Profile(this);
    p->show();
}
