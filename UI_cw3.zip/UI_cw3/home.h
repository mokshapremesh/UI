#ifndef HOME_H
#define HOME_H

#include <QDialog>
#include "profile.h"
#include <QTextEdit>
#include <QScrollArea>

class QTextEdit;
class QTimer;

namespace Ui {
class Home;
}

class Home : public QDialog
{
    Q_OBJECT

public:
    explicit Home(QWidget *parent = nullptr);
    ~Home();

private slots:
    void on_profileButton_clicked();
    void on_viewComments_clicked();
    void showNotification();

private:
    Ui::Home *ui;
    Profile *p;

    QTextEdit *commentsTextEdit;
    QTimer *notificationTimer;

};

#endif // HOME_H
