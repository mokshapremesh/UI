#include "home.h"
#include "ui_home.h"
#include "profile.h"

Home::Home(QWidget *parent) :
    QDialog(parent)
{
    // Button on the left side of the search line
    QPushButton *addButton = new QPushButton("+", this);

    // Search line edit
    QLineEdit *searchEdit = new QLineEdit(this);
    searchEdit->setPlaceholderText("Logo or Search here");

    // Profile button
    QPushButton *profileButton = new QPushButton("My Profile", this);
    connect(profileButton, &QPushButton::clicked, this, &Home::on_profileButton_clicked);

    // Top layout with new button, search, and profile button
    QHBoxLayout *topLayout = new QHBoxLayout;
    topLayout->addWidget(addButton);
    topLayout->addWidget(searchEdit);
    topLayout->addWidget(profileButton);

    // Player frame placeholder
    QFrame *playerFrame = new QFrame(this);
    playerFrame->setFrameShape(QFrame::StyledPanel);
    playerFrame->setMinimumHeight(200);

    // Middle section for video player controls
    QPushButton *playButton = new QPushButton("play / stop", this);
    QSlider *timeSlider = new QSlider(Qt::Horizontal, this);
    timeSlider->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    QLabel *timeLabel = new QLabel("00:00:00", this);
    QComboBox *speedBox = new QComboBox(this);
    speedBox->addItem("1x");

    QHBoxLayout *middleLayout = new QHBoxLayout;
    middleLayout->addWidget(playButton);
    middleLayout->addWidget(timeSlider);
    middleLayout->addWidget(timeLabel);
    middleLayout->addWidget(speedBox);

    // Thumbnails section
    QPushButton *thumb1Button = new QPushButton("Video thumbnail1", this);
    QPushButton *thumb2Button = new QPushButton("Video thumbnail2", this);
    QPushButton *thumb3Button = new QPushButton("Video thumbnail3", this);

    // Set minimum size for thumbnail buttons
    thumb1Button->setMinimumSize(200, 80);
    thumb2Button->setMinimumSize(200, 80);
    thumb3Button->setMinimumSize(200, 80);

    QHBoxLayout *thumbnailLayout = new QHBoxLayout;
    thumbnailLayout->addWidget(thumb1Button);
    thumbnailLayout->addWidget(thumb2Button);
    thumbnailLayout->addWidget(thumb3Button);

    // Create a scroll area and set its widget to hold the thumbnail layout
    QScrollArea *thumbnailScrollArea = new QScrollArea(this);
    thumbnailScrollArea->setWidgetResizable(true);

    QWidget *thumbnailWidget = new QWidget;
    thumbnailWidget->setLayout(thumbnailLayout);

    thumbnailScrollArea->setWidget(thumbnailWidget);

    // Bottom section for comments
    QLabel *usernameLabel = new QLabel("Username", this);
    QTextEdit *commentsEdit = new QTextEdit(this);
    commentsEdit->setPlaceholderText("Comments");

    QVBoxLayout *commentsLayout = new QVBoxLayout;
    commentsLayout->addWidget(usernameLabel);
    commentsLayout->addWidget(commentsEdit);

    // Main layout
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(topLayout);
    mainLayout->addWidget(playerFrame);
    mainLayout->addLayout(middleLayout);
    mainLayout->addWidget(thumbnailScrollArea);
    mainLayout->addLayout(commentsLayout);

    // Set the layout for the QDialog
    setLayout(mainLayout);

    // Set a minimum size for the dialog
    // (Use iPhone SE as a reference)
    setMinimumSize(320, 650);
    resize(320, 650);
}

Home::~Home(){}

void Home::on_profileButton_clicked()
{
    hide();
    p = new Profile(this);
    p->show();
}
